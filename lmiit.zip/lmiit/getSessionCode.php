<?php 

include   ('include/dbconfig.php');	
	$sql="SELECT MAX(`id`) AS id FROM `session`";
	$res=mysql_query($sql);
	$row=mysql_fetch_assoc($res);
	if($row['id'] == "NULL")
	{
		echo "0001";
	}
	else
	{
		echo sprintf('%0' . 4 . 's', $row['id']+1);
	}
?>