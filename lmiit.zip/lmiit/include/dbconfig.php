<?php 
error_reporting(0);
$conn=mysql_connect("localhost","bankipur_lmiit","titan14#bhuT");
if(!$conn)
{
	echo "Database Error: ".mysql_error();
	exit();
}
mysql_select_db("bankipur_lmiit",$conn);
?>