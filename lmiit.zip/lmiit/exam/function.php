<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<div id="demo"></div>
	<script type="text/javascript">
	document.getElementById("demo").innerHTML=Math.floor(-1/2);
	</script>
</body>
</html>