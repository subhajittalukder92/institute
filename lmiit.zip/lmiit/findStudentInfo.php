<?php 
include "include/dbconfig.php" ;
include "include/no-cache.php" ;

if($_POST)
{
	$studentId = trim($_POST['studentId']) ;
	$sql="SELECT * FROM `student_info` WHERE `Student_Id`='$studentId'";
	$res=mysql_query($sql) ;
	$row=mysql_fetch_assoc($res) ;
	echo json_encode($row);
	
}
?>