<?php 
include "include/dbconfig.php";
$courseid=trim(isset($_POST['courseid']) ? $_POST['courseid'] : "") ;
$sql 		 ="SELECT * FROM `courses` WHERE `course_id`='$courseid'";
$res 		=mysql_query($sql);
if(mysql_num_rows($res) > 0)
{
	$row = mysql_fetch_assoc($res);
}
echo $row['course_fee']

?>

