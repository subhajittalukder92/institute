<?php 
session_start();
include('include/check-login.php');
error_reporting(0);
function encryptIt( $var )
{
    $cryptKey  = 'qJcB0rGtjk89Q2r54G03efyCp';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $var, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
}
function fetchRecords()
{
	include "include/dbconfig.php" ;
	$year=trim($_POST['year']);
	$session=trim($_POST['session']);
	$course=trim($_POST['course']);
	$month=trim($_POST['month']);
	/* $sql="
		SELECT * FROM (SELECT pursuing_course.student_id,pursuing_course.course_id,student_info.St_Name,student_info.regno,courses.course_name
		FROM pursuing_course 
		INNER JOIN student_info
		ON pursuing_course.student_id = student_info.Student_Id
		INNER JOIN courses
		ON pursuing_course.course_id=courses.course_id
		WHERE pursuing_course.course_id='$course')Q
		LEFT JOIN
		(SELECT payment.* ,pursuing_course.course_id AS csid,student_info.St_Name,student_info.regno FROM payment
		INNER JOIN pursuing_course
		ON pursuing_course.student_id=payment.student_id
		INNER JOIN student_info
		 ON student_info.Student_Id=pursuing_course.student_id
		WHERE pursuing_course.`course_id`='$course' AND pursuing_course.current_status='PURSUING'
		AND YEAR(payment.date)='$session' AND MONTH(payment.date)='$month'
		)P
		ON Q.student_id=P.student_id 
	"; */
	$sql="
		SELECT * FROM (SELECT pursuing_course.student_id,pursuing_course.course_id AS CID,student_info.St_Name,student_info.regno,courses.course_name
		FROM pursuing_course 
		INNER JOIN student_info
		ON pursuing_course.student_id = student_info.Student_Id
		INNER JOIN courses
		ON pursuing_course.course_id=courses.course_id
		WHERE pursuing_course.course_id='$course' AND pursuing_course.current_status='PURSUING' AND pursuing_course.`session_code`='$session' 
		)Q
 		LEFT JOIN
		(
		SELECT student_info.St_Name,student_info.regno,A.* FROM 
		(SELECT pursuing_course.session_code,temp.* 
		 FROM
		(SELECT `student_id` AS St_Id ,`course_id`,`date`,`receipt_no`, SUM(`payment_amt`) AS payment_amt FROM payment
		 WHERE YEAR(payment.date)='$year' AND MONTH(payment.date)='$month'
		GROUP BY `receipt_no`)temp
		INNER JOIN pursuing_course
		ON pursuing_course.student_id=temp.St_Id)A
		INNER JOIN pursuing_course
		ON pursuing_course.student_id=A.St_Id
		INNER JOIN student_info
		ON student_info.Student_Id=A.St_Id
		WHERE pursuing_course.`course_id`='$course' AND pursuing_course.current_status='PURSUING' AND
		A.session_code='$session'
		)P
		ON Q.student_id=P.St_Id 
	";
		/* echo $sql; */
	$res=mysql_query($sql);
	if(mysql_num_rows($res) > 0)
	{$no=0;
		while($row=mysql_fetch_array($res))
		{
			echo '
				<tr>
					<td style="text-align:center">'.++$no.'</td>
					<td style="text-align:center">'.$row['student_id'].'</td>
					<td style="text-align:center">'.$row[3].'</td>
					<td style="text-align:center">'.$row['course_name'].'</td>
					<td style="text-align:center">'.$row[2].'</td>
					<td style="text-align:center">'.$row['receipt_no'].'</td>
					<td style="text-align:center">'.printDate($row['date']).'</td>
					<td style="text-align:center">'.dueCheck($row['payment_amt']).'</td>
				</tr>
			
			';
		}
	}
}
function dueCheck($value)
{
	include "dbconfig.php";
	if($value == NULL)
	{
		return "<font color='red'>Due</font>";
	}
	else{
		return $value ;
	}
}
function printDate($value)
{
	if($value != NULL)
	{
		return date('d/m/Y',strtotime($value));
	}
	
}
?>
<?php include('include/menu.php');?>
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row ">
		 <h3 class="page-header">DUE INFORMATION</h3>
		 
		 <div class="col-md-12 col-sm-12 column" style="overflow-x:auto;">
	         
			
					<table id="example" class="table table-sm table-bordered">
						<thead>
							<th style="text-align:center;font-size:12px;">SL NO			</th>
							<th style="text-align:center;font-size:12px;">STUDENT ID		</th>
							<th style="text-align:center;font-size:12px;">REGISTRATION NO</th>
							<th style="text-align:center;font-size:12px;">COURSE NAME 	</th>
							<th style="text-align:center;font-size:12px;">STUDENT NAME 	</th>
							<th style="text-align:center;font-size:12px;">RECEIPT NO	</th>
							<th style="text-align:center;font-size:12px;">DATE	</th>
							<th style="text-align:center;font-size:12px;">AMOUNT	</th>
						</thead>
						<tbody>
							<?php fetchRecords(); ?>
							
						</tbody>
					</table>
					
		  		<!-- /col-md-6 -->
			  		<!-- /col-md-4 -->
		 
		  	<!-- /col-md-12 -->
	 	<!-- /row -->
      </div>
	 <p>&nbsp;</p>
	 <p>&nbsp;</p>
	 <p>&nbsp;</p>
	 <p>&nbsp;</p>
      </div>
			</div>
		</div>
		 <div class="clearfix"></div>
	</div>
</div>
</div>
<style>

</style>
<?php include('include/footer.php'); ?>
</body>
</html>
<script type="text/javascript">
$(document).ready(function() {
	
    var table = $('#example').DataTable( {
        lengthChange: true,
        buttons: [ 'copy', 'excel', 'pdf', 'print' ]
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
		
/* 	$('#example').Tabledit({
		url:"action.php",
		 buttons: {
				edit: {
					class : 'btn btn-xs btn-info',
					action : 'edit'
					}
		 },
		columns:{
			identifier:[1,"Student_Id"],
			editable:[[4,'St_Name'],[5,'Fathers_Name'],[6,'Mothers_Name'],[7,'Vill'],[8,'Post'],[9,'PS'],[10,'Dist'],[11,'Pin'],[12,'Contact_no'],[13,'contact2'],[14,'mstatus'],[15,'aadhar'],[16,'qualification'],[17,'Student_Occupation'],[18,'fathers_occupation']]
			},
			restoreButton:false,
			deleteButton:false,
			onSuccess:function(data,status,jqXHR)
			{
				if(data.action == "delete")
				{
					
					if(data.result == "success")
					{
						$('#'+ data.course_id).remove();
					}
					else if(data.result == "failed")
					{
						
						alert("ERROR: Unable To Delete.Try Again !")
					}
					else if(data.result == "invalid")
					{
						$('#myModal').modal('show');
					}
					
				}
			}
		
	}); */
		
	});
		
</script>