<?php 
include "include/dbconfig.php";
$input		 =filter_input_array(INPUT_POST);
$address	 =mysql_real_escape_string(trim($input["address"]));
$po			 =mysql_real_escape_string(trim($input["po"]));
$ps			 =mysql_real_escape_string(trim($input["ps"]));
$pin		 =mysql_real_escape_string(trim($input["pin"]));
$district	 =mysql_real_escape_string(trim($input["district"]));
$id			 =$input["id"];

if($input["action"] === 'edit')
{
 $query ="UPDATE `adress` SET `address`='$address',`po`='$po',`pin`='$pin',
		`ps`='$ps',`district`='$district' WHERE  `id`='$id'
		";
/* echo $query; */
	$res= mysql_query($query);
	if($res)
	{
		$input['result']="success";
	}
}
 if($input["action"] === 'delete')
{
		$sql="DELETE FROM `adress` WHERE `id`='$id'";
		/* echo $sql; */
		$res=mysql_query($sql);
		if($res)
		{
			$input['result']="success";
		}
		else{
			$input['result']="failed";
		}
	
}
echo json_encode($input);


?>