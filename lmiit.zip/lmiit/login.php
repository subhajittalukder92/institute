<?php
	session_start();
	require('include/dbconfig.php');
	
	$userid   = mysql_real_escape_string($_POST["userid"]);
	$password = mysql_real_escape_string($_POST["password"]);
	$_SESSION['timestamp'] = time();
	$q="select * from user_info where BINARY user_name='$userid' and BINARY password='$password'";
	$query = mysql_query($q);
	$row=mysql_fetch_assoc($query);
	if(mysql_num_rows($query)>0){
		$_SESSION['userid'] = $userid;
		$_SESSION['password'] = $password;
		$_SESSION['id'] = session_id(); 
		$_SESSION['login_type'] = $row['type'];
		/* echo $q; */
		echo '<script>window.location.assign("home.php");</script>';
		
	}
	else{
		echo '<script>alert("User id or Password is wrong.");window.location.assign("index.php");</script>';
	}
?>